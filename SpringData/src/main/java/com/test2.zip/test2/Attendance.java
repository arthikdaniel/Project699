package com.test2;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

public class Attendance {


    @Id
    private String id;
    private String studentId;
    private String courseId;
    private Date dateOfAttendance;
    private double hoursAttended;
    private String comments;

    public Attendance(String id, String studentId, String courseId, Date dateOfAttendance, double hoursAttended, String comments) {
        this.id = id;
        this.studentId = studentId;
        this.courseId = courseId;
        this.dateOfAttendance = dateOfAttendance;
        this.hoursAttended = hoursAttended;
        this.comments = comments;
    }

    public String getId() {
        return id;
    }

    public String getStudentId() {
        return studentId;
    }

    public String getCourseId() {
        return courseId;
    }

    public Date getDateOfAttendance() {
        return dateOfAttendance;
    }

    public double getHoursAttended() {
        return hoursAttended;
    }

    public String getComments() {
        return comments;
    }

    @Override
    public String toString() {
        return "Attendance{" +
                "id='" + id + '\'' +
                ", studentId='" + studentId + '\'' +
                ", courseId='" + courseId + '\'' +
                ", dateOfAttendance=" + dateOfAttendance +
                ", hoursAttended=" + hoursAttended +
                ", comments='" + comments + '\'' +
                '}';
    }
}
