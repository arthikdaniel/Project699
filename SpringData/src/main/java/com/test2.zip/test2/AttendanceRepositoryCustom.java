package com.test2;


import java.util.List;

public interface AttendanceRepositoryCustom {
    List<AttendanceSummary> aggregate(String studentId);
}