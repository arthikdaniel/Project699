package com.test2;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.query.Criteria;

import java.util.List;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;
import static org.springframework.data.mongodb.core.query.Criteria.where;

public class AttendanceRepositoryImpl implements AttendanceRepositoryCustom {

    private final MongoTemplate mongoTemplate;

    @Autowired
    public AttendanceRepositoryImpl(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    @Override
    public List<AttendanceSummary> aggregate(String studentId) {
        MatchOperation matchOperation = getMatchOperation(studentId);
        GroupOperation groupOperation = getGroupOperation();
        ProjectionOperation projectionOperation = getProjectOperation();

        return mongoTemplate.aggregate(Aggregation.newAggregation(
                matchOperation,
                groupOperation,
                projectionOperation
        ), Attendance.class, AttendanceSummary.class).getMappedResults();
    }

    private MatchOperation getMatchOperation(String studentId) {
        Criteria priceCriteria = where("studentId").in(studentId);
        return match(priceCriteria);
    }

    private GroupOperation getGroupOperation() {
        return group("courseId")
                .last("courseId").as("courseId")
                .addToSet("id").as("attendanceIds")
                .sum("hoursAttended").as("totalHours");
    }

    private ProjectionOperation getProjectOperation() {
        return project("attendanceIds", "totalHours")
                .and("courseId").previousOperation();
    }
}