package com.test;

import java.util.List;

public interface ProductRepositoryCustom {
    List<WarehouseSummary> aggregate(float minPrice, float maxPrice);
}