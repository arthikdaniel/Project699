package com.repo;

import com.didnotwork.custom.IAttendanceRepoCustom;
import com.model.Attendance;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.group;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.project;


public interface IAttendanceRepo extends MongoRepository<Attendance, String> {

    public List<Attendance> findByStudentId(@Param("studentId") String studentId);

    public List<Attendance> findByStudentIdAndCourseId(@Param("studentId") String studentId, @Param("courseId") String courseId);

    public List<Attendance> findByStudentIdOrderByCourseId(@Param("studentId") String studentId);


}