package com;


import com.test2.Attendance;
import com.test2.AttendanceRepository;
import com.test2.AttendanceSummary;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.hibernate.validator.internal.util.Contracts.assertNotNull;
import static org.junit.Assert.assertEquals;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
@WebAppConfiguration
public class AggregationApplicationTests {

    @Autowired
    private AttendanceRepository attendanceRepository;

    @Before
    public void setUp() {
        attendanceRepository.deleteAll();
    }

    @Test
    public void contextLoads() {
    }

    @Test
    public void findById() {
        Attendance attendance = new Attendance("AT1", "5b41b27ecd53f68149fce956", "5b3e81e9c428aa7b6473d4f5", new Date(), 2, "");
        attendanceRepository.save(attendance);
        Optional<Attendance> foundProduct = attendanceRepository.findById("AT1");
        System.out.println(foundProduct);
        assertNotNull(foundProduct);
    }

    @Test
    public void aggregateAttendance() {
        saveAttendances();
        List<AttendanceSummary> attendanceSummaries = attendanceRepository.aggregate("5b41b27ecd53f68149fce956");
        assertEquals(2, attendanceSummaries.size());
        AttendanceSummary sqlCourses = getStudentAttendance(attendanceSummaries);
        assertEquals(8.5, sqlCourses.getTotalHours(), 0.01);
        System.out.println(attendanceSummaries);
    }

    private void saveAttendances() {
        attendanceRepository.save(new Attendance("AT2", "5b41b27ecd53f68149fce956", "5b3e81e9c428aa7b6473d4f5", new Date(), 2, ""));
        attendanceRepository.save(new Attendance("AT3", "5b41b27ecd53f68149fce956", "5b3e81e9c428aa7b6473d4f5", new Date(), 2.5, ""));
        attendanceRepository.save(new Attendance("AT4", "5b41b27ecd53f68149fce956", "5b4fb17ccb53cea616141a9b", new Date(), 3.5, ""));
        attendanceRepository.save(new Attendance("AT5", "5b41b27ecd53f68149fce956", "5b4fb17ccb53cea616141a9b", new Date(), 1, ""));
        attendanceRepository.save(new Attendance("AT6", "5b41b27ecd53f68149fce956", "5b3e81e9c428aa7b6473d4f5", new Date(), 1.5, ""));
        attendanceRepository.save(new Attendance("AT7", "5b41b27ecd53f68149fce956", "5b4fb17ccb53cea616141a9b", new Date(), 4, ""));
    }

    private AttendanceSummary getStudentAttendance(List<AttendanceSummary> attendanceSummaries) {
        return attendanceSummaries.stream().filter(attendance -> "5b4fb17ccb53cea616141a9b".equals(attendance.getCourseId())).findAny().get();
    }
}